/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen2evaluacion;

public class Hexagono extends Figura {

    public Hexagono(int base, int altura) {
        super(base, altura);
    }

    @Override
    public double area() {
        return (this.perimetro()*(altura/2))/2;
    }

    @Override
    public double perimetro() {
        return 6*base;
    }
}
