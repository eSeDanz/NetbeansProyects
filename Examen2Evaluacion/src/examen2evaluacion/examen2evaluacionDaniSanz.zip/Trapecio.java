/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen2evaluacion;

public class Trapecio extends Figura {

    private int Base;

    public Trapecio(int base, int altura, int Base) {
        super(base, altura);
        this.Base = Base;
    }

    @Override
    public double area() {
        return (base + Base)*altura/2;
    }

    @Override
    public double perimetro() {
        double x;
        x= (Base-base)/2;
        double c;
        c=Math.sqrt(Math.pow(altura, 2)+Math.pow((double)x, 2));
        return base+c+c;
    }
    
    @Override
    public String toString() {
        return super.toString()
                + "\nBase Grande: " + this.Base;
    }

    public void setBase(int Base) {
        this.Base = Base;
    }
}
